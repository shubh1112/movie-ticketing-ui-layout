export interface Seat {
  seatNumber: string,
  booked: boolean,
  seatCost: number
}